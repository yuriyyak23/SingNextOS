# Промпт продолжения: Root routing, local publication, pins, owner/interlock correctness

## Роль

Ты senior .NET/runtime и capability-security engineer, implementation/refactoring agent SingNextOS. Заверши оставшуюся часть плана «Root routing, local publication, pins, owner/interlock correctness» через реальные consumers: исправление поведения → необходимая verification → следующий dependency-ready consumer. Результат — работающий код с сохранёнными invariants и actual closure/reclaim consequences. Audit, документационный handoff и green suite сами по себе не закрывают runtime scope. Не расширяй задачу до всего v6 или production qualification; не дроби связанный source block на бесконечные test-only micro-slices.

## Вводные

Repo: `\SingNextOS`. Очередь: `docs\SingNextOS-v6-modernize`. Нормативные owners/contracts/ADR: `docs\SingNextOS-v6-roadmap-reworked-2026-09-23`.

HybridCPU ISE: `\HybridCPU ISE`. Разрешены compiler и External Tools Runtime/Tool/Provider: `HybridCPU_ExternalRuntime`, `HybridCPU_ExternalRuntime.Contracts`, `Tools`. Local fixes на resolved contracts не требуют sibling source edits. Изменение sibling source не обновляет NuGet dependencies SingNextOS автоматически; актуальные packages/toolchain определяй по project/assets/global inputs. Перед HybridCPU Git командами проверь наличие metadata; путь не Git identity.

Порядок чтения: applicable AGENTS.md → modernize/00-README.md → 01-STATE-AND-BACKLOG.md → 02-IMPLEMENTATION-ORDER.md → 03-DEV-VALIDATION.md. Для выбранного seam — normative02/04/05 и только relevant contract/phase/ADR/report. Phase описывает target semantics и contour exits, а не текущий перечень отсутствующего кода. Не загружай всю историю, proof matrix и frozen manifests. Очередь в 01 единственная; prompt не второй backlog.

Это handoff на 2026-10-09. Actual tree, scoped diff, процессы, terminal logs/TRX/exits, source/callers и очередь имеют приоритет над dated facts. Dirty дерево содержит пользовательские changes/deletions. Перед каждой записью перечитай actual file и scoped diff. Не reset/clean/rollback/restore deleted/commit. Не меняй чужой active pool и tested inputs живого runner.

`SingPlus.Boot` и его Samples полностью исключены: Boot failures показывать отдельно; functionality/references/classification ради green не менять. Shared solution/contracts/packages требуют fresh attribution. Java исключена: Java-only checks явно skipped, независимые .NET/PowerShell/native/model consumers продолжаются. ISA/opcodes/encoding/register state/memory model/pipeline/retire/firmware/reset/machine legality не менять; ISA impact NONE без отдельного ADR и разрешения. Все новые gates OFF.

### Текущее состояние и стартовый consumer

Завершён старый guest release/child closure pending блок: `artifacts/v6/iteration-20261009-foreign-guest-closure/child-release-report.md`. Не возобновлять его и не повторять успешный focused ради оформления.

Последние согласованные runtime blocks:

- `iteration-20261009-provider-original-child-guest`: same original provider records, запрет foreign receipt/failure transfer, live root/backing inventory и отсутствие re-pin после законно потреблённой closure.
- `iteration-20261009-rematerialization-owner-inventory`: bounded-copy original inventory reader под existing lifecycle gate; executable consumer tests больше не требуют foreign transfer.
- `iteration-20261009-root-secure-original-owner`: same original SecureDomainRecord, canonical/routing identity, live dependency inventory, retained receipt при late owner loss, exact consumed closure без повторного pin.
- `iteration-20261009-root-device-original-owner`: same original DeviceLeaseRecord; shared device/MMIO/IRQ/Virtual-I/O/CXL resolution и root/process inventory удерживают незавершённые original facts.
- `iteration-20261009-device-canonical-root`: device composition требует same root record в routing и `_activeSubjects` до effect/publication/unfinished cleanup; pre-effect refusal balances pending, late refusal не вызывает compensation через потерянный root. Terminal focused и main broad exit 0 записаны в report; это не новая qualification и не общий atomicity exit.

Их reports находятся в `artifacts/v6/<slice>/report.md`; читать только затронутые. Historical failures сохранены. Каждый pass относится к своим recorded inputs; latest suite не заменяет все прежние проверки. Unchanged VerifiedExisting guards пропускай без нового report/test campaign.

**Первый следующий consumer:** secure creation/publication canonical root continuity. В current `PlatformAuthorityBridge.SecureCompute.cs` pre-effect, cleanup и final publication checks ещё используют `_domains.TryGetValue` и reference к captured parent; device-only `TryGetCanonicalRootRecord` там не применён. Это кандидат, не доказанный defect. Установи actual kernel CreateSecureDomain/bridge callers, admission/source callbacks и final local commit. Проверь absent/foreign canonical `_activeSubjects` owner при сохранённом root route до effect и после provider callback. Установи actual invocation/no-effect, retained original receipt, publication и backing/reclaim consequence. Existing secure-owner inventory fix не начинать заново; он не доказывает этот отдельный ROOT boundary.

Relevant files: `PlatformAuthorityBridge.cs`, `PlatformAuthorityBridge.SecureCompute.cs`, `PlatformAuthorityBridge.SecureExecution.cs`, actual kernel secure callers и `tests/SingPlus.Tests/Platform/Phase7EvidenceSecureComputeTests.cs`. Related device reference — `PlatformDeviceLeaseTests.cs`. Нового secure canonical-root repro/fix этот handoff не утверждает.

## Задача

1. Перед изменением classify requirement: VerifiedExisting / Partial / Missing / Contradicted / ExternalBlocked / FutureGated. Назови admission linearization, external effect, final publication, local fact consumption и closure/reclaim boundaries. Проверяй actual caller и последствия, а не helper вместо consumer. Если unchanged VerifiedExisting — переходи дальше.
2. Заверши secure canonical-root consumer при подтверждённом gap и согласованные соседние source/closure boundaries. Сохрани original facts и no-repeat при late refusal. После final coherent changes выполни affected focused и одну applicable broad, затем общий короткий report/audit и одну backlog запись. Не объявляй pending broad завершённым блоком.
3. Продолжай оставшиеся dependency-ready local routing/publication/pin/interlock consumers: absent/foreign routes, equal-tuple original owner continuity, late mutable source/owner loss, overlap cleanup, exception/reentry, exact local consumption и actual Region/quantitative reclaim. Связанные guards объединяй по owner/callers и effect/closure boundaries; не выбирай лишь самый лёгкий проходящий тест.
4. Отдельно оцени concurrent atomicity и durable routing/recovery при потере original owner. Serial model callbacks и восстановление того же record в тесте не закрывают all-fact-loss/reboot recovery. До provider/API расширения установи actual producing consumer и resolved contract need. При dependent blocker сохрани pins/gates OFF, зафиксируй concrete gap и продолжай независимую работу.
5. Завершение всей выбранной части докажи requirement-by-requirement по current source/callers и actual consequences: реализовано, contradicted, incomplete, weak/missing evidence или external/future blocker. Один green suite не закрывает scope. Общий goal сохраняй до доказанного завершения; не подменяй его документацией или меньшим bounded exit.

### Invariants и owners

Один logical fact — один existing authoritative owner: CapabilityAuthority — permission; ProcessRegistry — incarnation; VirtualDomainAuthority — domain/ancestors/local mapping; KernelEventRegistry — local events/waiters; RegionAuthority — use/damage/backing; ExternalOperationAuthority — operation lifecycle; ResourceBudgetAuthority — quantitative truth. Provider владеет admission/generation/closure; current HybridCPU legality независима. Compiler/proof/refinement/trace/identity/mapping/receipt не permission и не второй ledger. Не вводи новые authority/GlobalState.

Admission = SingNext authorization AND provider admission AND semantic refinement AND current HybridCPU legality; применимые части проверять независимо. Unknown mandatory semantics deny; downgrade требует fresh admission. Mutable owner/source/generation tuple проверять у actual owner до effect и на final commit. Pending — admission interlock, не permission/closure.

Existing owner сохраняет original fact до exact consumption. Routing/canonical index может ссылаться на тот же owner record; копия, equal tuple и чужой receipt не identity continuity. Missing/not-found/Closed projection не closure. Completed lifetime fact не permission, но законно потреблённая closure не требует новой active admission и не должна создавать вечный pin после epoch change. Unfinished cleanup требует fresh applicable mutable sources по контракту.

Completion, visibility, publication, persistence, durability, release различны. Cancel/timeout/not-found/exception/transport loss/terminal response не containment/no-effect/closure/reclaim. Local staged rollback не доказывает отсутствие provider effect. Known exact original receipt сохранять при late publication refusal. Unknown/malformed original outcome pinned/quarantined; returned-object compensation не закрывает original invocation. Reclaim требует exact original tuple/fact и actual consumer; charge/reservation не стирать по metadata.

Callbacks/provider composition/notifications/trace sinks — вне capability/owner commit locks. После callback — fresh local checks; balanced existing interlocks. Reentry/throw не теряет fact и не повторяет effect. Не добавляй fictitious release/closure API или re-reservation, скрывающую ownership gap. Сохраняй V1/additive semantics; public enum/API/schema/V2 — только proven need и applicable ADR.

### Contract/provider gaps — не выдавать за local closure

- Neutral execution имеет Bind/Start; exact artifact release API/consumer не установлен. Admitted artifact pre-unmap refusal уже реализован; pins сохранить.
- Exact unknown original-invocation containment query у resolved Poll/Complete/Revoke/Close не установлен. No-repeat/quarantine остаются fallback.
- Production nested/secure/event/trap/Virtual-I/O/DMA execution не следует из models/fakes/emulator. Producing consumer и конкретную guarantee установить отдельно; новые gates OFF.
- SubmitV6Restart, SettleResourceExternalOperation, standalone AssignPool и BindCoherentAccess не становятся dependency-ready по наличию API/test callback. P03/P08 и остальные фазы вне root scope до отдельного concrete consumer; stateful resume/multi-host/physical properties не local exits.

### Verification и record

Применяй modernize/03; не добавляй обязательные campaigns ради оформления.

- До каждого dotnet проверить live processes/full command lines и previous terminal log/TRX/exit. Один runner пересекающегося SingNextOS graph; чужие процессы не завершать. Отсутствие процесса не stable epoch: сверить affected source/test/project/assets/global drift. Не менять tested tuple/canonical digest/validator inputs до terminal. При конфликте — disjoint review/docs, verification pending.
- Restore только при missing assets/dependency changes; далее `--no-restore`. MSBuild commands: `-m:1 -nr:false -p:UseSharedCompilation=false`. Focused compile заменяет duplicate build.
- Source block: meaningful affected behavior/negative/race/fault tests после final changes. Shared runtime/teardown — одна applicable broad после согласованного блока. Broad scope выбирай по affected graph: provider-only suite не новая main-runtime integration qualification. Повторы лишь final fix/failure/drift/concrete unresolved risk. Test-only — focused, broad при integration/harness risk.
- Не сокращай применимые security parser/canonical/source digests, unknown mandatory, exact receipt/generation и actual closure/reclaim races. Новые tests нужны для отсутствующей проверки изменённого поведения/риска, не для копирования implementation.
- Attribution: scoped diff + snapshot либо selected relevant source hashes; actual resolved packages/toolchain. Не full-tree inventory, не snapshot+hash+duplicate diff. Unchanged inputs можно связать с prior record после relevant drift check.
- Один substantive coherent runtime block — короткий `report.md` + compatible `audit.json`: requirements/test/fault IDs, classification/exits/open gaps, owners/locks/boundaries, changed files/API/schema/package delta, actual commands/counts/durations/scope/tuple, gates/claim ceiling/blockers/fallback, Java/ISA. Failed history сохранять; не отдельный record на каждый тест. Backlog обновить одной краткой записью; counts/commands и journal не копировать в очередь/phase docs.
- Documentation-only: semantic/diff/changed-link review без build/restore/P00/runtime report/audit/SHA/manifest refresh. MANIFEST/SHA256SUMS исторические; refresh перед настоящим freeze. Qualification/full supply-chain/formal/perf/hardware campaigns — только по applicable property/claim/risk. Нормативные security integrity и strict qualification exits не ослаблять.

Claims описывают отдельные properties/contours, не лестницу. Managed dev guard не требует physical proof; models/fakes/emulator/compiler/unit tests его не дают. Reservation не minimum service/deadline/WCET; telemetry не автоматически charge. Все новые gates OFF; ProductionQualified не заявлять.

Финал по-русски: что изменено и зачем, actual tests/exits/limitations, bounded status/open gaps, evidence links, gates/claims, Java/ISA и следующий конкретный consumer. Goal не считать завершённым только из-за green build, record или handoff.
