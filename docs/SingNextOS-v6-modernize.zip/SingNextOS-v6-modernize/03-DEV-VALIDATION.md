# Проверки dev и qualification

Объём проверки определяется изменённым consumer, риском и заявляемым свойством. Qualification checklist и historical commands не добавляют обязательных dev запусков; unchanged verified consumers не перепроверять ради новой записи в плане. Dev exit подтверждает изменённое поведение на записанных inputs; production qualification остаётся отдельной задачей.

## Минимум по типу изменения

| Изменение | Проверка |
|---|---|
| Ordinary docs/prompts | Semantic/scope/diff review и изменённые локальные ссылки; без build/restore/P00, runtime report/audit, SHA или manifest refresh. Документ как input validator/canonical digest относится к соответствующему consumer |
| Изолированный source/refactoring блок | Actual callers/owners, affected compile и focused behavior/negative tests после final changes |
| Shared runtime/capability/teardown/P05/gates | Применимые focused fault/race tests и один applicable broad после согласованного блока на стабильных inputs |
| Contracts/schema/security canonicalization | Actual consumers, compatibility, parser/digest/unknown mandatory checks и exact tuple negatives; API/schema изменения — только при proven need и применимом ADR |
| Qualification/promotion/усиление claim | Evidence для конкретного свойства/contour; exact deployment qualification для production claim или gate enablement, physical evidence для physical properties |

Focused command, компилирующий affected graph, заменяет отдельный build. Использовать существующие meaningful tests; новые добавлять для отсутствующей проверки изменённого поведения или конкретного риска. Test-only strengthening требует focused; broad нужен при integration/harness risk. Повторять только affected проверку после final fix, relevant drift или unresolved risk; failure разобрать до повторного запуска. Applicable broad не откладывать за пределы блока; pending verification не считать exit. Тесты проверяют actual consequences, не повторяют helper logic.

## Security проверки, которые нельзя сокращать

Для затронутого consumer проверить каждую применимую часть admission независимо: authorization, provider admission, semantic refinement и current HybridCPU legality; mandatory unknown deny. Fresh mutable owner/source/generation tuple нужен до effect и на final commit. Проверить затронутые revoke/stop/ABA/publication/reentry/throw/lost-receipt/closure/reclaim races, capacity refusal до mutation/effect и balanced pending interlocks. Это перечень рисков для выбора проверок, а не требование полной матрицы на каждый блок.

Callbacks/composition/notifications/trace sinks — вне capability/owner commit locks. Known exact original receipt сохраняется при позднем publication refusal. Unknown/malformed original outcome pinned; failed response и returned-object compensation не доказывают original no-effect/closure. Reclaim требует exact original closure и actual consumer. Security canonical/source digests, consumed package integrity и receipt/generation validation сохраняются.

## Запуск и стабильность inputs

Эти правила запуска применяются только когда проверка требует dotnet. До каждого dotnet build/test/restore проверить live processes/full command lines и relevant terminal logs/TRX/exits. Один runner для пересекающегося SingNextOS graph; чужие процессы не завершать. Restore только при missing assets/dependency changes; далее `--no-restore`. Для MSBuild-based commands: `-m:1 -nr:false -p:UseSharedCompilation=false`.

Отсутствие процесса не доказывает отсутствие source writes. Shared run требует стабильных affected source/test/project/assets/global inputs. Согласованную паузу не запрашивать повторно без relevant drift; новая сессия требует проверки по фактам. Disjoint Boot работа допустима, shared solution/contracts/packages требуют fresh проверки. При конфликте продолжать независимую работу; verification оставить pending. Drift ограничивает attribution, после стабилизации повторить affected проверку.

Ожидание runner использовать для disjoint ordinary docs. Документы в tested tuple/canonical digest/inputs живого validator не менять до его завершения. Boot failures показывать отдельно; failed broad не скрывать и Boot не менять ради green.

## Attribution и record

Для source блока: scoped diff и один способ сохранить relevant dirty inputs — snapshot **либо** selected source hashes. Dependencies/packages/toolchain определять по actual project/assets/global inputs. HEAD alone недостаточен. Неизменные inputs можно связать с prior record после проверки relevant drift; full-tree/package inventories, snapshot вместе с hashes и повторные diff captures не обязательны. Fresh scope diff перед записью нужен для сохранения пользовательских changes, но не требует нового архивного capture каждой micro-правки.

Record относится к законченному согласованному блоку, а не к каждой правке или запуску. Для substantive runtime блока — короткий `report.md` и compatible `audit.json` в `artifacts/v6/<unique-slice>`. Записать consumer и существующие применимые requirement/test/fault IDs (не вводить новые только ради record), результат/open gaps, значимые owners/locks/boundaries, changed files и фактические verification exits/scope/attribution. Commands/counts/durations хранить здесь один раз; API/schema/package delta и claim ceiling указывать при изменении либо связывать с неизменным prior record. Blockers/fallback, Java/ISA — по scope. Неприменимые поля не раздувать; failed history сохранять. Dev collector не build/promotion authority.

Micro-fix и test-only strengthening включать в запись согласованного блока; отдельная пара report/audit на каждый тест или правку не нужна. Unchanged VerifiedExisting пропускать: новый record и evidence campaign не требуются.

Logs/TRX/exits и attribution связать ссылками, без копирования их содержимого или обязательного collector. Отсутствие итогового record обозначать как record pending; оно само по себе не требует повторять успешный запуск на неизменных inputs. После verification обновить одну краткую запись/link в файле 01; counts хранить в runtime report, кроме временного статуса без готового report. Historical evidence не переписывать, journal в phase docs не копировать. Documentation-only задача не требует завершать pending runtime verification или оформлять runtime record. При обнаружении уже выполненной проверки обновить статус по её logs/exits и relevant inputs; отсутствие report само по себе не превращает реализованный код в Missing.

## Qualification и более сильные evidence

Full freeze не prerequisite dev exit. Qualification/promotion, security/dependency/toolchain change или concrete unresolved risk определяют affected checks, не все campaigns автоматически. Dependency change требует integrity/consumer checks; formal/model — для соответствующего свойства; perf — для hot-path risk/performance claim; hardware — для physical property. External blocker блокирует только dependent contour. Java-only checks skipped, не passed.

MANIFEST/SHA256SUMS не регенерировать ради dev cleanup. Strict Freeze/Qualify не ослаблять: historical manifest drift остаётся failed exit, explicit refresh нужен перед настоящим freeze. Gate/claim changes требуют применимой exact deployment qualification.

Новые gates OFF. Models/fakes/emulator/compiler/unit tests не physical proof или ProductionQualified evidence. Claims относятся к отдельным properties/contours и не образуют лестницу; managed RuntimeEnforced guard не требует physical campaign для своего dev exit.
