# Состояние и очередь модернизации

Актуально на 2026-10-09. Статусы ниже относятся к названным consumers, а не к завершению всей фазы. Перед работой сверить текущие source/callers, scoped diff и relevant report: dirty дерево не определяется одним HEAD или историческими counts.

## Реализованные срезы — не повторять без defect/drift

Это навигация по consumers, а не журнал запусков. Каждый report подтверждает только свой recorded tuple; более поздний report не заменяет все предыдущие проверки.

| Consumer | Bounded exit / relevant report |
|---|---|
| Wave1 и kernel events | Integration и event source/local publication реализованы; возвращаться только при конкретном defect/drift |
| Root/mapping admission и cleanup | Capacity/pending guards, original outcome retention и teardown pins реализованы: [root revoke](../../artifacts/v6/iteration-20261007-root-revoke-intent-atomicity/report.md), [mapping Begin](../../artifacts/v6/iteration-20261007-mapping-begin-outcome/report.md) |
| P05 observations | Raw execution quarantine и negative sink/reentry consumers: [runtime](../../artifacts/v6/iteration-20261007-p05-execution-quarantine-observation/report.md), [negative consumers](../../artifacts/v6/iteration-20261007-p05-observation-negative-consumers/report.md). Trace не permission/reclaim |
| IRQ/MMIO/DMA/device/mapping | Original admitted sources и cleanup/no-repeat: [IRQ endpoint-only routing](../../artifacts/v6/iteration-20261008-irq-endpoint-only-route/report.md), [MMIO](../../artifacts/v6/iteration-20261008-mmio-admitted-source-lifetime/report.md), [DMA](../../artifacts/v6/iteration-20261008-dma-admitted-source-lifetime/report.md), [parent mapping](../../artifacts/v6/iteration-20261008-device-mapping-parent-lifetime/report.md). IRQ exit требует live original endpoint owner |
| Child/guest/artifact | Create outcome retention, admission/final commit и interlocks реализованы. Точки входа в relevant records: [nested lineage/publication](../../artifacts/v6/iteration-20261008-nested-lineage-publication/report.md), [guest sources](../../artifacts/v6/iteration-20261008-bridge-guest-source-lifetime/report.md), [artifact Bind/Start](../../artifacts/v6/iteration-20261008-artifact-admission-atomicity/report.md), [artifact original parent](../../artifacts/v6/iteration-20261008-artifact-fault-original-parent/report.md). Более ранние records читать для конкретного затронутого boundary |
| Secure compute | Create/bind/transition/revoke и exact region closure: [final closure](../../artifacts/v6/iteration-20261008-secure-region-final-closure-source/report.md). Captured original guest/child pending completion и final publication: [secure guest](../../artifacts/v6/iteration-20261008-secure-guest-original-pending/report.md) |
| Virtual event/trap delivery | Original request/raw outcome retention и обязательный actual publication commit: [report](../../artifacts/v6/iteration-20261008-virtual-delivery-original-outcome/report.md). Production event/trap execution этим не qualified |
| CXL fabric/memory | Original device/root release, fabric publication/completion и original memory invocation retention реализованы: [fabric final cleanup](../../artifacts/v6/iteration-20261008-cxl-fabric-original-final-commit/report.md), [fabric publication](../../artifacts/v6/iteration-20261008-cxl-fabric-original-publication/report.md), [memory invocation](../../artifacts/v6/iteration-20261008-cxl-malformed-memory-invocation/report.md). Admitted memory parent имеет bounded exit: [report](../../artifacts/v6/iteration-20261008-cxl-memory-admitted-original-parent/report.md). Восстановление owner в тесте не закрывает durable recovery |
| CXL Type-2/backing/security | Captured original operation parent до Submit/publication/cleanup: [Type-2](../../artifacts/v6/iteration-20261008-cxl-type2-original-operation-parent/report.md). Original fabric/memory для Region damage и release: [backing consequence](../../artifacts/v6/iteration-20261008-cxl-original-backing-consequence/report.md). Readiness до/после provider queries: [security source](../../artifacts/v6/iteration-20261008-cxl-security-original-effect-source/report.md) |
| Secure/CXL concurrent consumers | Actual guest Bind и composed publication проверены с concurrent source loss, overlap/closure refusal, pending balance и retained pins: [report](../../artifacts/v6/iteration-20261008-concurrent-secure-cxl-lifetime/report.md). Runtime guards VerifiedExisting; это bounded managed exit, не general platform atomicity или durable recovery |
| Dev evidence test harness | IDE failure `pwsh` not found исправлен: existing PowerShell 7 разрешается независимо от PATH, явный override сохраняется. Полный focused policy consumer прошёл без pwsh в PATH и без override; assertions не ослаблены. [Report](../../artifacts/v6/iteration-20261008-root-original-subject-owner/report.md) |

Exact original receipts сохраняются при позднем publication refusal; unknown outcomes удерживают pins. Эти exits не закрывают recovery, artifact release или production qualification. Child pre-effect refusal — [ADR-011](../SingNextOS-v6-roadmap-reworked-2026-09-23/ADR-011-CHILD-CREATE-INVOCATION-DISPOSITION.md); nested его не наследует. Exact Start refusal — [ADR-010](../SingNextOS-v6-roadmap-reworked-2026-09-23/ADR-010-CHILD-START-NOT-ACCEPTED.md).

## Последние bounded root exits

Точки входа для current consumer review; source/callers и recorded inputs имеют приоритет. Counts и commands остаются в reports. Эти exits не закрывают весь root scope и не заменяют qualification.

| Связанный блок | Evidence / граница |
|---|---|
| Guest/parent release и child closure | [Общий child/release record](../../artifacts/v6/iteration-20261009-foreign-guest-closure/child-release-report.md). Старый pending release handoff завершён; не повторять focused ради оформления |
| Root/mapping original fact и quantitative consumption | [Original reclaim](../../artifacts/v6/iteration-20261009-root-original-reclaim/report.md), [consumed settlement](../../artifacts/v6/iteration-20261009-consumed-mapping-settlement/report.md), [mapping charge identity](../../artifacts/v6/iteration-20261009-mapping-charge-index/report.md). Completed exact fact не требует fresh active admission |
| Provider original routing/closure | [Root](../../artifacts/v6/iteration-20261009-provider-original-root/report.md), [mapping](../../artifacts/v6/iteration-20261009-provider-original-mapping/report.md), [artifact](../../artifacts/v6/iteration-20261009-provider-original-artifact/report.md), [child/guest](../../artifacts/v6/iteration-20261009-provider-original-child-guest/report.md). SAME records, no foreign receipt transfer; artifact release остаётся gap |
| Bounded-copy inventory reader | [Record](../../artifacts/v6/iteration-20261009-rematerialization-owner-inventory/report.md). Reader сериализован existing owner gate; executable cleanup tests больше не требуют foreign receipt/failure transfer |
| Kernel secure owner inventory | [Record](../../artifacts/v6/iteration-20261009-root-secure-original-owner/report.md). Original secure record retained, absent/foreign routes и late canonical-owner loss удерживают root/backing; canonical ROOT callback boundary проверяется отдельно |
| Kernel device owner и child sources | [Original device record](../../artifacts/v6/iteration-20261009-root-device-original-owner/report.md), [canonical root composition](../../artifacts/v6/iteration-20261009-device-canonical-root/report.md). Device/MMIO/IRQ/Virtual-I/O/CXL source checks требуют original identities; последний source block имеет terminal focused и main broad exit 0 на его inputs |

## Очередь

| Приоритет | Classification / consumer | Следующее действие / открытая граница |
|---|---|---|
| 1 | P10 Partial: Root routing, local publication, pins, owner/interlock correctness | Secure/child/nested canonical continuity, surviving original root inventory, root outcome identity и secure composition: [общий requirement-by-requirement record](../../artifacts/v6/iteration-20261009-secure-canonical-root/report.md). Actual legacy mapping teardown сохраняет original intent/outcome и запрещает повторный effect без completion contract: [no-repeat/pins](../../artifacts/v6/iteration-20261009-legacy-revoke-original/report.md). Exact consumption/reclaim guards сохранены. Следующий concrete consumer: bridge Faulted/unpublished original effect reconciliation с durable original-invocation routing producer; existing budget journal не восстанавливает root facts. Установить producer и resolved exact containment contract до API расширения. General atomicity/all-fact-loss recovery и provider gaps ниже открыты; неизменные guards без defect/drift не повторять |
| 2 | P10 Partial: failure/cleanup consumers | Durable routing при потере всех original routes, bridge Faulted/generic failed-outcome recovery и unpublished original effects. Учесть реализованные original-source guards выше; восстановление owner в тесте не закрывает recovery. Unknown-poll и artifact release имеют contract gaps ниже |
| 3 | P08 Partial: restart-only | При просмотре src/tools 2026-10-08 production caller `SubmitV6Restart` не найден. Test callbacks не executable qualification. Установить provider consumer, fresh admission/legality и no duplicate effect. Stateful capture/resume — FutureGated |
| 4 | A0 Partial: architecture policy | [Current non-Boot project edges](../../artifacts/v6/iteration-20261008-a0-nonboot-project-edges/report.md) проверяются существующей matrix; forbidden/conditional/unresolved/escaping references deny, archives исключены из active graph. Full A0 остаётся открытым: Boot/Samples вне scope; удалённый full guard и user classification не восстановлены. Это StaticAdmission policy exit, не runtime/whole-system claim |

## Границы, которые не закрыты retention-тестами

- Unknown-poll recovery: resolved platform/neutral Poll/Complete/Revoke/Close не имеет exact original unknown-invocation containment query. DeliveryUncertain/pins сохраняются; повторный effect и local staged rollback не доказывают containment. [Contract gap](../../artifacts/v6/iteration-20261008-irq-delivery-original-owner/report.md).
- Artifact release: actual neutral execution contract имеет Bind/Start; exact release API не установлен. Отказ до neutral unmap при admitted artifact уже реализован, в том числе до execution attempt: [report](../../artifacts/v6/iteration-20261007-p10-artifact-unmap-pin/report.md). Его recorded broad имел failures; этот report не считать green integration exit. Без resolved release contract/consumer pins сохраняются.
- Production nested/secure providers не установлены; fault/model callbacks не заменяют их. HybridCpu event provider возвращает ChildContourBlocked; production trap provider не установлен.
- Virtual-I/O: actual producing consumer не установлен. Unsupported/test-only path не executable qualification.
- Provider DMA остаётся RuntimeAdmission без submit surface; admission guards не доказывают DMA execution.
- Standalone `AssignPool` не получает original capability/process/device tuple; production caller не установлен. RegionOwner/metadata не становятся authority. `BindCoherentAccess` также не имеет production caller в текущем src/tools search; аналогичный malformed compensation path остаётся отдельным gap.

При blocker продолжать независимый consumer. Не добавлять fictitious closure API и не объявлять original invocation закрытым по returned-object compensation.

## Отложенные направления и claims

P02/P09/P07/P12/P06 брать только при concrete consumer и его applicable checks. P11 — FutureGated после relevant single-host exits. PCL — optional optimization, не prerequisite. QV1 — exact single-host staged executable lifecycle до actual release, не whole-system claim. Shared atomic/coherent, durability и physical properties требуют своих contracts/evidence; dev green их не доказывает.

Все новые gates OFF; P04/P05/P10 остаются Partial, ProductionQualified не установлен. Boot/Samples исключены, Java-only skipped, ISA NONE.

## История

Reports authoritative только для своих recorded inputs. Counts/commands/failed history остаются в reports, а historical «next» не является текущей задачей. [Архив прежней таблицы](../../artifacts/v6/iteration-20261006-roadmap-modernize-split/history/docs__SingNextOS-v6-roadmap-reworked-2026-09-23__41-CURRENT-STATE-AND-OPEN-SLICES.md) читать лишь при конкретном regression/trace вопросе.

Предыдущая развёрнутая root строка и устаревший prompt сохранены в [истории handoff](../../artifacts/v6/iteration-20261009-root-documentation-cleanup/history/01-STATE-AND-BACKLOG.md). Читать выборочно; relative links в архиве относятся к прежнему расположению документа. История не задаёт следующую задачу.
