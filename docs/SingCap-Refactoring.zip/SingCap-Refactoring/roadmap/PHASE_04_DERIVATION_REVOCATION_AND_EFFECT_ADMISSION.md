# Phase 04 — Derivation, Revocation and Effect-Admission Linearization

## Goal

Make delegation and revocation correct under concurrency and prevent the classic `Validate -> Revoke -> Effect` race.


## Baseline source anchors

- SingNextOS `a67eea1aafc72054d22f1586b62c6883cdc71681`
- HybridCPU-v2 `794c4a53494f503855ac8cf209efab23fde083b2`
- Technical specification: `../SINGCAP_M_TECHNICAL_SPEC.md`


## Parent-child derivation

- child linkage and parent validity are established atomically;
- parent link is immutable;
- bounded depth is checked at derive time;
- cycles are impossible;
- child stores/can reach the same revocation lineage node/account.

## Subtree revocation

Current direct V1 revoke is insufficient for descendants. Implement one selected model:

```text
bounded ancestry walk
or
shared revocation node/epoch tree
```

The model must have deterministic complexity bounds and cache invalidation semantics.

## Operation authority lease

Introduce a privileged internal primitive conceptually equivalent to:

```text
AcquireOperationAuthority(
    subject,
    capability,
    exact resource/generation,
    exact operation,
    session?,
    consume/quota request?)
        -> OperationAuthorityLease
```

The acquisition is the linearization point for starting a new effect. A plain descriptor returned by `Validate` is not enough.

The lease is not a durable authority token for application code. It is trusted runtime/sentry state for one exact effect attempt.

## Revocation semantics for in-flight work

Define three distinct outcomes:

```text
new effect admission     blocked after revoke
already-admitted effect  follows operation/cancellation policy
publication/release      separately revalidated where required
```

Revocation cannot claim to undo an irreversible provider action already submitted.

## One-shot consume

One-shot state and quota consumption occur in the same authoritative transaction/lock/linearization domain as effect admission.

## Primary paths

```text
src/Runtime/SingPlus.Runtime/Capabilities/CapabilityAuthority.cs
src/Runtime/SingPlus.Runtime/RuntimeKernel.cs
src/Runtime/SingPlus.Runtime/ExternalOperations/*
src/Runtime/SingPlus.Runtime/Services/*
tests/SingPlus.Tests/Capabilities/*
tests/SingPlus.Tests/Runtime/*
```

## PR slices

- **P04-1:** derivation graph/node + bounded depth.
- **P04-2:** subtree revocation and cache invalidation.
- **P04-3:** derive-vs-revoke stress semantics.
- **P04-4:** operation authority lease for one internal pilot effect.
- **P04-5:** one-shot/quota atomic consume.

## Tests

Deterministic barrier-based concurrency tests:

- derive linearizes before/after revoke;
- validate descriptor succeeds then revoke occurs — later effect without lease is denied by migrated pilot;
- lease acquired before revoke follows documented in-flight policy;
- two one-shot consumers => exactly one succeeds;
- quota consume races never overspend;
- revoked ancestor invalidates deep child;
- stale cache epoch cannot authorize.

## Exit criteria

No effectful migrated path uses `Validate()` result alone across an unbounded race window. Subtree revocation behavior is observable and stress-tested.
