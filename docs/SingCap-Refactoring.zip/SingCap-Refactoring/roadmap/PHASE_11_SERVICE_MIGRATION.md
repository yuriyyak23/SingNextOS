# Phase 11 — Representative Service Migration

## Goal

Move real SingNextOS services onto the strengthened ledger/seal/sentry model in small independently reversible waves.


## Baseline source anchors

- SingNextOS `a67eea1aafc72054d22f1586b62c6883cdc71681`
- HybridCPU-v2 `794c4a53494f503855ac8cf209efab23fde083b2`
- Technical specification: `../SINGCAP_M_TECHNICAL_SPEC.md`


## Migration order

### Wave A — Network/socket

Mostly completed as Phase-06 pilot; remove compatibility shortcuts after qualification.

### Wave B — File service

Preserve session/object generation semantics but replace paired `{FileObjectHandle + capability}` plumbing where the new sealed handle can encode the exact object reachability safely. Namespace/create authority remains a separate explicit capability.

### Wave C — Process service

Maintain strict separation:

```text
ProcessHandle = identity
Process control capability/sealed control object = authority
```

Child creation/delegation uses the single capability ledger and atomic quota/depth rules.

### Wave D — selected GUI/queue/TLS/session objects

Only migrate services that actually exist and have a concrete use case. Do not invent `SharedArena` to make migration uniform.

## Confused-deputy review

For every method record:

```text
caller identity
resource/object being acted on
required explicit authority
exact target subject
whether delegation occurs
whether external effect occurs
whether Region ownership/borrow changes
what closes authority on failure
```

A service's own internal privilege does not authorize it to use a caller-supplied resource unless the caller provided the exact required authority.

## Primary paths

```text
src/Runtime/SingPlus.Runtime/NativeServices/RuntimeNativeServiceHosts.cs
src/Sip/SingPlus.Sip/FileSystem/
src/Sip/SingPlus.Sip/Networking/
src/Sip/SingPlus.Sip/Process/
src/Sip/SingPlus.Sip/Gui/
contracts/SingPlus.Contracts/NativeServiceContracts.cs
tests/SingPlus.Tests/NativeServices/
```

## PR slices

One service family per PR. Each PR carries compatibility adapter, negative tests and rollback flag only while migration is incomplete.

## Tests

Per service:

- guessed object token;
- right object wrong caller/session;
- revoked object capability;
- service restart/stale handle;
- sibling object enumeration/substitution;
- rights/operation widening;
- exception/cancel cleanup;
- delegated response authority exactly declared;
- process identity does not imply terminate/debug authority.

## Exit criteria

Network, filesystem and process control each demonstrate the strengthened model in production runtime code, not only model/tests. Compatibility V1 paths are either removed or explicitly non-ManagedCap legacy surfaces.
